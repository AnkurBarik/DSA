# ludo2
A simple ludo game , made by using basic html css and js .2
